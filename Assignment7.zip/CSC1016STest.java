/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Reece
 */
public class CSC1016STest {

    public CSC1016STest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getName method, of class CSC1016S.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        CSC1016S instance = new CSC1016S();
        String testString = "Larry";
        instance.setName(testString);
        String expResult = testString;
        String result = instance.getName();
        assertEquals(expResult, result);
    }

    @Test
    public void testZeros() { //tests if all zeroes are inputted then output(Final) should be zero
        System.out.println("Zeroes");
        CSC1016S instance = new CSC1016S();
        int mark = 0;
        instance.setMark("practests", mark);
        instance.setMark("pracs", mark);
        instance.setMark("exam", mark);
        instance.setMark("tests", mark);
        float expResult = 0.0F;
        float result = instance.getFinal();
        assertEquals(expResult, result, (float) 0.00);
    }

    @Test
    public void testHundreds() { //tests if all hundreds are inputted then output(Final) should be one hundred
        System.out.println("Hundreds");
        CSC1016S instance = new CSC1016S();
        int mark = 100;
        instance.setMark("practests", mark);
        instance.setMark("pracs", mark);
        instance.setMark("exam", mark);
        instance.setMark("tests", mark);
        float expResult = 100.0F;
        float result = instance.getFinal();
        assertEquals(expResult, result, (float) 0.00);
    }

    /**
     * Test of getFinal method, of class CSC1016S.
     */
    @Test
    public void testGetFinal() { //tests inputs between 0 and 100 and checks if output applies to formula
        System.out.println("getFinal");
        CSC1016S[] instance = new CSC1016S[100];
        float[] expResult = new float[100];
        float[] result = new float[100];
        for (int mark = 1; mark < 100; mark++) {
            instance[mark]=new CSC1016S();
            instance[mark].setMark("practests", mark);
            instance[mark].setMark("pracs", mark);
            instance[mark].setMark("exam", mark);
            instance[mark].setMark("tests", mark);
            expResult[mark] = (float) (0.15 * mark + 0.15 * mark + 0.10 * mark + 0.60 * mark);
            result[mark] = instance[mark].getFinal();

        }
        assertArrayEquals(expResult, result, (float) 0.0000);

    }

}
