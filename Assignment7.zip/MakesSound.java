/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Reece Gounden
 */
public interface MakesSound { //Interface that is implemented by Cat,Cow,Dog
    public String makeNoise();
}
