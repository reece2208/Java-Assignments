/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Reece Gounden
 */
public class SoftDrink implements Comparable<SoftDrink>{
    private String name,colour,vol; //initialize instance variables

    public SoftDrink(String name, String colour, String vol) { //constructor
        this.name = name;
        this.colour = colour;
        this.vol = vol;
    }

    public String getName() {
        return name;
    }

    public String getColour() {
        return colour;
    }

    public String getVol() {
        return vol;
    }
    
    public String toString() //toString method
    {
        return name+" "+colour+" "+vol;
    }

    @Override
    public int compareTo(SoftDrink t) { //Overwritten compareTo method so that static sort method can be used on class to sort alphabetically
        return (name+colour+vol).compareTo(t.getName()+t.getColour()+t.getVol());
    }
    
    
}
