
import java.util.ArrayList;
import static java.util.Collections.sort;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Reece Gounden
 */
public class Question1 {
    public static void main(String[] args) {
        ArrayList<SoftDrink> sd = new ArrayList<>();
        Scanner kb = new Scanner(System.in);
        System.out.println("");
        String temp;
        int c;
        do{ //menu loop
            System.out.println("Enter option: (1) add soft drink (2) quit:");
            c=kb.nextInt();
            if(c==2)
            {  break;}
            System.out.println("Enter name, colour and volume in ml separated by space");
            temp = kb.next();
            temp +=kb.nextLine();
            sd.add(new SoftDrink(temp.split(" ")[0],temp.split(" ")[1],temp.split(" ")[2])); //add new object instance to list
            
        }while(c==1);
        sort(sd); //sort list
        for(SoftDrink sd1:sd) //iterate through list
        {
            System.out.println(sd1.toString()); //print out each object in list using toString method
        }
    }
}
