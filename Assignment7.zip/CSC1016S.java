/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Student
 */
public class CSC1016S implements Student{
    private String name;
    
    private int pracs,practests,tests,exam; //instance variables
    
    @Override
    public void setName(String name) {
        this.name=name;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setMark(String category, int mark) {
        switch(category) //depending on parsed string the method will initialise a certain variable
        {
            case "pracs":
                this.pracs=mark;
                break;
            case "practests":
                this.practests=mark;
                break;    
            case "tests":
                this.tests=mark;
                break;
            case "exam":
                this.exam=mark;
                break;    
        }
    }

    @Override
    public float getFinal() { 
        return (float) (0.15*pracs+0.15*tests+0.10*practests+0.60*exam); //return final mark based on formula given in notes to students document (Vula)
    }
    
}
