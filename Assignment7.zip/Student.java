interface Student 
{
   public void setName ( String name );
   public String getName ();
   public void setMark ( String category, int mark );
   public float getFinal ();   
}
