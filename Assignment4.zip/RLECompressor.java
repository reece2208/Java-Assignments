
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Reece
 */
public class RLECompressor {

    String[] out;

    public RLECompressor() {

        //output array with same length as input array
    }

    public String[] compress(String[] inp) {
        int cnt = 0;
        this.out = inp;
        for (String inp1 : inp) {

            out[cnt] = process(inp1);

            cnt++;
        }
        return out;
    }

    public String process(String in) {
        String outLine = "";
        String temp;
        char[] charArr = in.toCharArray();
        int cnt = 0;
        int stack = 1;

        for (char c : charArr) {
            if (cnt + 1 != charArr.length) {
                if (stack == 9) {
                    outLine += "9" + Character.toString(c);
                    stack = 1;
                }
                else if (in.charAt(cnt) == in.charAt(1 + cnt)) {
                    stack++;
                } else if (stack > 1) {
                    outLine += stack + Character.toString(c);
                    stack = 1;
                } else if (Character.isDigit(c) && stack == 1) {
                    outLine += "1" + Character.toString(c);
                } else if (stack == 1) {
                    outLine += Character.toString(c);
                }

                cnt++;
            } else {
                if (stack > 1) {
                    outLine += stack + Character.toString(c);
                } else if (stack == 1 && Character.isDigit(c)) {
                    outLine += 1 + Character.toString(c);
                } else {
                    outLine += Character.toString(c);
                }
            }

        }
        return outLine;
    }

}
