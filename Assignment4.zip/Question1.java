
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Reece
 */
public class Question1 {

    public static void main(String[] args) {
        ArrayList<String> input = new ArrayList<>();
        RLECompressor rle = new RLECompressor();
        Scanner kb = new Scanner(System.in);
        System.out.println("Input text (leave blank line to end):");

        String in = kb.nextLine();
        input.add(in);
        while (!in.equals("")) {
            
            in = kb.nextLine();
            input.add(in);
        }
        String[] inp = new String[ input.size() ];
        input.toArray(inp);
        //System.out.println(input);
        System.out.println("Compressed version:");
        for(String each:rle.compress(inp)){
            System.out.println(each);
            
        }
        
    }

}
