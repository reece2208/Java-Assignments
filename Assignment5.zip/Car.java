/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class Car extends Vehicle {
    
    private int doors;
    
    public Car(String colour,int passengers,int doors) {
        super(passengers, colour);
        this.doors=doors;
    }
    
    public String toString(){
        return super.toString()+" "+doors+" doors";
    }
    
}
