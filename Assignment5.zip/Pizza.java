/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class Pizza extends Food {

    private String base,cheese,garlic;
    
    public Pizza(String itemid, String size,String base,String cheese,String garlic) {
        super(itemid, size);
        this.base=base; 
        this.cheese=cheese;
        this.garlic=garlic;
    }

    @Override
    public String toString() {
        return "Pizza"+super.toString()+", "+base+", "+cheese+", "+garlic; //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
//pizzas (menu item number, size, base, extra cheese, extra garlic)