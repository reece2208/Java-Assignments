/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class PtLine extends VectorObject {

    private int bx, by;

    PtLine(int id, int x, int y, int bx, int by) {
        super(id, x, y);
        this.bx = bx;
        this.by = by;
        //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void draw(char[][] matrix) { //algorithm from http://rosettacode.org/wiki/Bitmap/Bresenham's_line_algorithm#Java (Wikipedia Sourced)
        // delta of exact value and rounded value of the dependant variable
        int d = 0;

        int dy = Math.abs(y - by);
        int dx = Math.abs(x - bx);

        int dy2 = (dy << 1); // slope scaling factors to avoid floating
        int dx2 = (dx << 1); // point

        int ix = bx < x ? 1 : -1; // increment direction
        int iy = by < y ? 1 : -1;

        if (dy <= dx) {
            for (;;) {
                matrix[by][bx]='*';
                if (bx == x) {
                    break;
                }
                bx += ix;
                d += dy2;
                if (d > dx) {
                    by += iy;
                    d -= dx2;
                }
            }
        } else {
            for (;;) {
                matrix[by][bx]='*';
                if (by == y) {
                    break;
                }
                by += iy;
                d += dx2;
                if (d > dy) {
                    bx += ix;
                    d -= dy2;
                }
            }
        }
        //To change body of generated methods, choose Tools | Templates.
    }

}
