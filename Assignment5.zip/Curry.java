/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class Curry extends Food {
    
    private String type;
    
    public Curry(String itemid, String size,String type) {
        super(itemid, size);
        this.type=type;
    }
 
    @Override
    public String toString() {
        return "Curry"+super.toString()+", "+type; //To change body of generated methods, choose Tools | Templates.
    }
    
}
//curries (menu item number, size, curry type)