/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class HLine extends VectorObject {

    private int len;

    HLine(int id, int x, int y, int len) {
        super(id, x, y);
        this.len = len;
    }

    @Override
    public void draw(char[][] matrix) {
        for (int px = x; px < x + len; px++)//Draws horz. line of length len starts from y
                {
            matrix[y][px] = '*';
        }
    }

}
