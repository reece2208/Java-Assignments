/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class SoftDrink extends Food{
    
    private String flavour;
    private String vessel;
    
    public SoftDrink(String itemid,String size,String flavour,String vessel){
        super(itemid,size);
        this.flavour=flavour;
        this.vessel=vessel;
    }

    @Override
    public String toString() {
        return "Soft Drink"+super.toString()+", "+flavour+", "+vessel; //To change body of generated methods, choose Tools | Templates.
    }
}
  
//softdrinks (menu item number, size, flavour, bottle or can)
