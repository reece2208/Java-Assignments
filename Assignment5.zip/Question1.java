import java.util.*;

class Question1
{
   public static void main ( String args [] )
   {
      System.out.println (new Vehicle (2, "Blue"));
      System.out.println (new Car ("Black", 4, 4));
      System.out.println (new Plane ("White", 416, "Boeing", 737));
   }
}
