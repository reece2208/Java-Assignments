/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class Plane extends Vehicle{
    
    private String manufacturer;
    private int modelno;
    

    public Plane(String colour,int passengers,String manufacturer,int modelno) {
        super(passengers, colour);
        this.modelno=modelno;
        this.manufacturer=manufacturer;
    }
    
    public String toString(){
        return super.toString()+" "+manufacturer+" "+modelno;
    }


}
