
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Reece
 */
public class Question2 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        char menu;
        String itemno,size, base, cheese, garlic, vessel, type, flavour;
        System.out.println("Welcome to Great International Food Court");
        Food[] f = new Food[100];
        int cnt = 0;

        loop:
        do {
            System.out.println("MENU: add (P)izza, add (C)urry, add (S)oft drink, (D)elete, (L)ist, (Q)uit");
            menu = kb.next().charAt(0);

            switch (menu) {
                case 'P' | 'p':
                    System.out.println("Enter the menu item number");
                    itemno = kb.next();
                    System.out.println("Enter the size");
                    size = kb.next();
                    System.out.println("Enter the base");
                    base = kb.next();
                    System.out.println("Enter extra cheese");
                    cheese = kb.next();
                    System.out.println("Enter extra garlic");
                    garlic = kb.next();

                    f[cnt] = new Pizza(itemno, size, base, cheese, garlic);
                    System.out.println("Done");
                    cnt++;
                    break;
                case 'C' | 'c':
                    System.out.println("Enter the menu item number");
                    itemno = kb.next();
                    System.out.println("Enter the size");
                    size = kb.next();
                    System.out.println("Enter the curry type");
                    type = kb.next();

                    f[cnt] = new Curry(itemno, size, type);
                    System.out.println("Done");
                    cnt++;
                    break;
                case 'S' | 's':
                    System.out.println("Enter the menu item number");
                    itemno = kb.next();
                    System.out.println("Enter the size");
                    size = kb.next();
                    System.out.println("Enter the flavour");
                    flavour = kb.next();
                    System.out.println("Enter whether it is a bottle or can");
                    vessel = kb.next();

                    f[cnt] = new SoftDrink(itemno, size, flavour, vessel);
                    System.out.println("Done");
                    cnt++;
                    break;
                case 'D' | 'd':
                    System.out.println("Enter the menu item number");
                    itemno = kb.next();
                    int cnt2 = 0;
                    for (Food item : f) {
                        try{
                        if (item.getItemid().equalsIgnoreCase(itemno)) {
                            f[cnt2] = null;
                            System.out.println("Done");
                            continue loop;
                        }
                        }catch(Exception e)
                        {
                            
                        }

                        cnt2++;
                    }
                    System.out.println("Not found");
                    break;
                case 'L' | 'l':
                    for (Food item : f) {
                        if (item != null) {
                            System.out.println(item.toString());
                        }

                    }
                    System.out.println("Done");
                    break;
                case 'Q' | 'q':
                    System.exit(0);
            }

        } while (menu != 'q');

    }
}
