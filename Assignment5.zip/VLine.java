/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class VLine extends VectorObject {

    private int len;

    VLine(int id, int x, int y, int len) {
        super(id, x, y);
        this.len = len;
    }

    @Override
    public void draw(char[][] matrix) {
        for (int py = y; py < y + len; py++)//Draws vert. line of length len starts from y
                                {
            matrix[py][x] = '*';
        }
    }

}
