/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class Rectangle extends VectorObject {

    private int xLen, yLen;

    Rectangle(int id, int x, int y, int xLen, int yLen) {
        super(id, x, y);
        this.xLen = xLen;
        this.yLen = yLen;
    }

    @Override
    public void draw(char[][] matrix) {
        for (int px = x; px < x + xLen; px++)//x matrix placement
                {
            for (int py = y; py < y + yLen; py++)//y matrix placement
                                                {
                matrix[px][py] = '*';
            }
        }
    }

}
