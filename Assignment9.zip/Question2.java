
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Reece
 */
public class Question2 {

    public static void main(String[] args) {
        System.out.println("Enter a string to test:");
        String in = (new Scanner(System.in)).nextLine(); //read in string
        Stack stk = new Stack(); //instantiate stack
        char bc;
        boolean fault = false;

        for (char i : in.toCharArray()) { //checks each char in String 'in'

            if ("{[(<".contains(i + "")) { //pushes to stack if opening bracket
                stk.push(i);
            } else if ("}])>".contains(i + "")) {
                if (!stk.empty()) { //checks that stack isnt empty
                    bc = (char) stk.pop();
                    if (bchecker(i, bc)) { //run bracket check
                        System.out.println("error: '" + i + "' does not match with '" + bc + "'.");
                        fault = true; //flags as a fault/error
                        break;
                    }
                } else { //if stack is empty but close bracket is detected
                    System.out.println("error at end: the close bracket '" + i + "' does not have a corresponding opening bracket.");
                    fault = true;
                }

            }
        }
        if (!fault && !stk.empty()) {
            System.out.println("error at end: opening bracket '" + stk.pop() + "' remains unclosed.");
        } else if (!fault) {
            System.out.println("The string is correct! There are no mismatched brackets.");
        }
    }

    private static boolean bchecker(char b, char bc) { //checker method
        return ((b == ')' && bc != '(') || (b == '}' && bc != '{') || (b == '>' && bc != '<') || (b == ']' && bc != '['));

    }
}
