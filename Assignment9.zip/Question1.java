
import java.util.LinkedList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Reece
 */
public class Question1 {

    public static void main(String[] args) {
        LinkedList<String> queue = new LinkedList<>();
        Scanner kb = new Scanner(System.in);
        String in;
     

        do {
            in = kb.nextLine();//read input in
            if (!in.equals("O")) {
                queue.add(in);//add to list
            } else {
                try {
                    System.out.println("Data: "+queue.getFirst());
                    queue.removeFirst();
                } catch (Exception e) {
                    System.out.println("Buffer empty");
                }
            }
            //output item from list, use counter to keep track of which items have been output
        }while (!in.equals("X"));
    }

}
