
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class Question1 {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        Scanner rd = new Scanner(new FileReader(args[0]));
        LinkedList<String> list = new LinkedList<>();
        int cnt=1;
        String temp;
        while(rd.hasNextLine()){
            temp=rd.nextLine();
            list.add(cnt
                    + "/"
                    + temp.replaceAll("\\s+", "").length()
                    +": "+temp);
            cnt++;
        }
        ListIterator<String> iter = list.listIterator();
        while(iter.hasNext()){
            System.out.println(iter.next());
        }
    }
}
