/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author Reece
 */
public class SimpleLinkedListTest {
    
    public SimpleLinkedListTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of constructor method, of class SimpleLinkedList.
     */
    @Test
    public void testConstructor() {
        System.out.println("SimpleLinkedList");
        ArrayList arrobj = new ArrayList();
//        arrobj.add("Jane");
//        arrobj.add("John");
//        arrobj.add("Joe");
        
        SimpleLinkedList instance = new SimpleLinkedList(arrobj.toArray());
        ArrayList result = new ArrayList();
        Iterator itr = instance.iterator();
        while(itr.hasNext()){
            result.add(itr.next());
        }
        
        ArrayList expResult = arrobj;
        
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    /**
     * Test of indexOf method, of class SimpleLinkedList.
     */
    @Test
    public void testIndexOf() {
        System.out.println("indexOf");
        
        Object value = null;
        SimpleLinkedList instance = new SimpleLinkedList();
        int expResult = 0;
        int result = instance.indexOf(value);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of insert method, of class SimpleLinkedList.
     */
    @Test
    public void testInsert() {
        System.out.println("insert");
        int index = 0;
        Object item = null;
        SimpleLinkedList instance = new SimpleLinkedList();
        instance.insert(index, item);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

}
