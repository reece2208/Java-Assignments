
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

/**
 *
 * @author Reece
 */
public class Question2 implements Comparator<ListObj> {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner rd = new Scanner(new FileReader(args[0]));
        LinkedList<ListObj> list = new LinkedList<>();
        Question2 q2 = new Question2();
        int cnt = 1;
        String temp;
        while (rd.hasNextLine()) {
            temp = rd.nextLine();
            ListObj ob = new ListObj(temp);
            list.add(ob);
            cnt++;
        }
        Collections.sort(list, new Question2());

        for (int i = 0; i < list.size(); i++) {
            System.out.println(i + 1 + list.get(i).toString());
        }
    }

    @Override
    public int compare(ListObj o1, ListObj o2) {
        return o1.line.length() - o2.line.length();
    }

}
