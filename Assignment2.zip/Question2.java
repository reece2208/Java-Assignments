import java.text.NumberFormat;
import java.util.Scanner;

/**
 * Assignment 2 Question 2 driver class
 */
public class Question2 {

    public static void main(String[] args) {
        VendingMachine vm = new VendingMachine();

        System.out.println("***** Welcome to Vending Machines R Us *****");

        int option = Integer.MAX_VALUE;
        Scanner s = new Scanner(System.in);

        while (option != 0) {
            System.out.println("Choose an option:");
            System.out.println("0. Quit ");
            System.out.println("1. Create new vending machine (old one will go away) ");
            System.out.println("2. Buy a can");
            System.out.println("3. Calculate turnover");
            System.out.println("4. Calculate profit");
            System.out.println("5. Check how many cans are left");

            option = s.nextInt();
            NumberFormat currencyInstance = NumberFormat.getCurrencyInstance();

            switch (option) {
                case 1:
                    System.out.println("Enter amount that supplier charged per can (Rand):");
                    float costPrice = s.nextFloat();
                    System.out.println("Enter amount that vending machine will charge (Rand):");
                    float askingPrice = s.nextFloat();
                    System.out.println("Enter starting number of cans:");
                    int numCans = s.nextInt();
                    vm = new VendingMachine();
                    vm.initialise((int) (costPrice * 100), (int) (askingPrice * 100), numCans);
                    System.out.println("Vending machine initialised with " + numCans + " cans");
                    break;
                case 2:
                    if (vm.buyCan()) {
                        System.out.println("Success! You can't beat the feeling!");
                    } else {
                        System.out.println("No cans left, sorry!");
                    }
                    break;
                case 3:
                    
                    System.out.println("Turnover to date is: " + currencyInstance.format(vm.getTurnover() / 100f));
                    break;
                case 4:
                    System.out.println("Profit to date is: " + currencyInstance.format(vm.getProfit() / 100f));
                    break;
                case 5:
                    System.out.println(vm.getRemainingCans() + " can(s) remaining");
                    break;
                case 0:
                    System.out.println("Goodbye");
                    break;
            }
        }
    }
}
