
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class Question1 {
    public static void main(String asd[])
    {
      Scanner kb = new Scanner(System.in);
      Building build = new Building();
      
      System.out.print("Enter honorary name: ");
      String hono_name = kb.nextLine();
      System.out.print("Enter department name: ");
      String dept_name = kb.nextLine();
      
      build.setnames(hono_name,dept_name);
      System.out.println("The building name is: "+build.getname());
    }
}
