/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class VendingMachine {
    
    private int numCans;
    private int costPrice,salePrice;
    private int cansSold;
    private double turnover,profit;
    
    public void initialise(int i, int i0, int numCans) {
       this.numCans=numCans;
       this.costPrice=i;
       this.salePrice=i0;
       //To change body of generated methods, choose Tools | Templates.
    }

    public boolean buyCan() {
        if(numCans>0)
        {
            numCans--;
            cansSold++;
            turnover+=salePrice;
            profit+=(salePrice-costPrice);
            return true;
        }
        else
        {
            return false;
        }//To change body of generated methods, choose Tools | Templates.
    }

    public double getTurnover() {
        return turnover;
    }

    public double getProfit() {
        return profit;
    }

    public String getRemainingCans() {
        return numCans+"";
    }

    public boolean refill(int i, int i0, int numCans) {
        if(this.numCans==0)
        {
            this.numCans+=numCans;
            this.costPrice=i;
            this.salePrice=i0;
            return true;
        }
        else
        {
            return false;
        }
        
                
              
     }

    public boolean refill(int numCans) {
    if(this.numCans==0)
        {
            this.numCans+=numCans;
            return true;
        }
        else
        {
            return false;
        }
        }
}
    
    
    

