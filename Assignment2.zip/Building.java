/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class Building {

    String hono_name;
    String dept_name;
    
    public void setnames(String hono_name, String dept_name) {
        this.hono_name=hono_name;
        this.dept_name=dept_name;//To change body of generated methods, choose Tools | Templates.
    }

    public String getname() {
        return hono_name+" "+dept_name+" "+"Building";//To change body of generated methods, choose Tools | Templates.
    }
    
}
