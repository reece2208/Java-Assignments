
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Reece
 */
public class Question3 {//driver class for Q3

    public static void main(String asd[]) {
        Scanner kb = new Scanner(System.in);
        Polynomial pn = new Polynomial();
        
		System.out.println("**** Polynomial Calculator *****");
        
		char term = 'y';
        boolean op = true;
        
		while (op) {
            switch (term) {
                case 'y':
                    System.out.println("Enter term exponent:");
                    int exp = kb.nextInt();
                    System.out.println("Enter term coefficient:");
                    int coe = kb.nextInt();
                    pn.addTerm(coe, exp);
                    System.out.println( pn.toString());
                    System.out.println("Would you like to add another term? (y/n)");
                    term = kb.next().charAt(0);
                    break;

                case 'n':
                    System.out.println("Enter value for X");
                    int x = kb.nextInt();
                    System.out.println("P(" + x + ") = " + pn.evaluate(x));
                    op = false;
                    break;
                default:
                    op = false;
                    break;
            }
        }
    }
}
