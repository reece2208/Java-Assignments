/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class ClockAngle {
    
    private int angle;
    private int hour;
    private int minute;
    
    public ClockAngle(int time)
    {
        if(time<100)
        {
            time+=1200;
        }
        
        if(time>1259)
        {
            time-=1200;
        }
        
        String strtime=Integer.toString(time);
        
        minute = (360/60)*Integer.parseInt(strtime.substring(strtime.length()-2)); // minute and hour are converted to degrees
        hour = (360/12)*Integer.parseInt(strtime.substring(0,strtime.length()-2));
        
        angle=Math.abs(hour-minute);
        
        if(angle>180) //if angle calculated was the large angle then gets the small angle
        {
            angle=360-angle;
        }
       
         
    }
    
    
    
    public int getAngle()
    {
        return angle;
    }
}
