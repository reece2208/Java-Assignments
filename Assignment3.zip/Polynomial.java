
import java.util.*;

/**
 * Assignment 3 Question 3 Polynomial Class distributed to students.
 *
 * @version 1.0
 */
public class Polynomial {

    //HIGHLY recommended that you do not access this instance variable,
    // except through the pre-existing addTerm, getCoefficient, getHighestExponent
    // and getLowestExponent methods. Those methods are all you need for this question.
    private SortedMap<Integer, Integer> terms;
    // Terms are stored in <exponent, coefficient> pairs. The Map orders
    // entries in ascending order of key.

    /**
     * Construct a new Polynomial object. The polynomial has no terms until
     * terms are added using addTerm()
     */
    public Polynomial() {
        terms = new TreeMap<Integer, Integer>();
    }

    /**
     * Add a new term to the polynomial. Note that if a term with this exponent
     * exists already, the two terms are added together and stored as a single
     * term instead of two distinct terms.
     *
     * @param coefficient Co-efficient of the new term, e.g. the '3' in 3x^2
     * @param exponent Exponent of the new term, e.g. the '2' in 3x^2
     */
    public void addTerm(int coefficient, int exponent) {
        int existingCoefficient = terms.get(exponent) == null ? 0 : terms.get(exponent);
        terms.put(exponent, existingCoefficient + coefficient);
    }

    /**
     * Get the biggest exponent in this polynomial
     *
     * @return the exponent
     */
    private int getHighestExponent() {
        return terms.lastKey();
    }

    /**
     * Get the smallest exponent in this polynomial
     *
     * @return the exponent
     */
    private int getLowestExponent() {
        return terms.firstKey();
    }

    /**
     * Get the co-efficient of a term with the specified exponent
     *
     * @param exponent the exponent
     * @return the co-efficient if the term exists, zero otherwise
     */
    private int getCoefficient(int exponent) {
        if (terms.containsKey(exponent)) {
            return terms.get(exponent);
        } else {
            return 0;
        }
    }

    //your evaluate method here
    public double evaluate(int x) { //method to evaluate the function for parsed 'x' value
        int high = getHighestExponent();
        int low = getLowestExponent();

        double coEff=1,pow = 1;
        double sum = 0;
        
        while (high >= low) {
            if (high == 0) {
                sum += getCoefficient(0);
            } else if (high < 0) {
                for (int i = low; i < 0; i++) {
                    coEff *= x;
                }
                sum += (1 / coEff) * getCoefficient(high);
            } else {
                for (int i = 1; i <= high; i++) {
                    pow *= x;
                }

                sum += pow * getCoefficient(high);

            }
            high -= 1;
            pow = 1;
            coEff = 1;
        }

        return sum;
    }

    //your toString method here
    public String toString() { //method to return string of function

        String start = "Polynomial is now: P(x) = ";
        String px = "";

        int high = getHighestExponent();

        for (int k = getHighestExponent(); k >= getLowestExponent(); k--) { //Runs for all int values between the highest and lowest exponents
            if (getCoefficient(k) == 0) {

            } else if (high == 0 && getLowestExponent() == 0) {
                px += (getCoefficient(0) + "");

            } else if (getCoefficient(k) == 1 && getHighestExponent() != 1) {
                px += "x^" + ("" + (k));
            } else if (getCoefficient(k) != 1 && getHighestExponent() == 1) {
                px += (getCoefficient(k) + "") + "x";
            } else if (getCoefficient(k) == 1 && getHighestExponent() == 1) {
                px += "x";
            } else {
                px += (getCoefficient(k) + "") + "x^" + ("" + (k));
            }

            if (k == getLowestExponent()) {
            } else {
                if (getCoefficient(k) == 0) {
                } else {
                    px += " + ";
                }
            }
            high -= 1;
        }

        if (px.startsWith("-")) { 
            return (start + "- " + px.substring(1).replace("+ -", "- ").replace("x^0", "").replace("x^1", "x"));
        } else if (px.equals("")) {
            return start + 0 + "";
        } else {
            return (start + (px).replace("+ -", "- ").replace("x^0", "").replace("x^1", "x"));
        }
    }

}
