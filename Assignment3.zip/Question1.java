import java.util.Scanner;

/**
 * Assignment 3 Question 1 driver class for ClockAngle
 */
public class Question1 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("**** Welcome to Angle Calculator ****");
        do {
            System.out.println("Enter 4-digit time: (0000 - 2359)");
            int time = s.nextInt();
            if (time < 0 || time > 2359) {
                System.out.println(time + " is not a valid time");
            } else {
                System.out.println("Angle between hour hand and minute hand is: " + new ClockAngle(time).getAngle()  + " degrees");
            }
            System.out.println("Would you like to calculate the angle for another time? (y/n)");
        } while ("y".equalsIgnoreCase(s.next()));
    }
}
