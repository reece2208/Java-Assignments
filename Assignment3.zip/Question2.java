
import java.text.DecimalFormat;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Reece
 */
public class Question2 { //driver class for Q2
    

    public static void main(String []args)
    {
    DecimalFormat df = new DecimalFormat("0.00");
    SimCalculator MYNsim = new SimCalculator(3,7,"082","MYN");
    SimCalculator Yodasim = new SimCalculator(4,5,"072","Yodacom");
    Scanner kb = new Scanner(System.in);
    Scanner st = new Scanner(System.in);
    int option=1;
    System.out.println("Welcome to SIM Calculator");
    while (true) {
            
            System.out.println("Choose option:");
            System.out.println("1. Calculate cost of call using MYN SIM");
            System.out.println("2. Change call rates for MYN SIM");
            System.out.println("3. Calculate cost of call using Yodacom SIM");
            System.out.println("4. Change call rates for Yodacom SIM");
            System.out.println("5. Quit");

            option = kb.nextInt();

            switch (option) {
                case 1:
                    System.out.println("Enter number to call:");
                    String numMYN = kb.next();
                    System.out.println("Enter duration in seconds:");
                    int durMYN = kb.nextInt();
                    System.out.println("Cost of call would be: R"+df.format(MYNsim.checkCallCost(numMYN, durMYN)/100.0));
                    break;
                case 2:
                    System.out.println("Enter new in-network rate: (R/sec)");
                    int inRateMYN = (int)(kb.nextDouble()*100);
                    System.out.println("Enter new out-of-network rate: (R/sec)");
                    int outRateMYN = (int)(kb.nextDouble()*100);
                    MYNsim.setRates(inRateMYN, outRateMYN);
                    System.out.println("Success!");
                    break;
                case 3:
                    System.out.println("Enter number to call:");
                    String numYoda = kb.next();
                    System.out.println("Enter duration in seconds:");
                    int durYoda = kb.nextInt();
                    System.out.println("Cost of call would be: R"+df.format(Yodasim.checkCallCost(numYoda, durYoda)/100.0));
                    break;
                case 4:
                    System.out.println("Enter new in-network rate: (R/sec)");
                    int inRateYoda = (int)(kb.nextDouble()*100);
                    System.out.println("Enter new out-of-network rate: (R/sec)");
                    int outRateYoda = (int)(kb.nextDouble()*100);
                    Yodasim.setRates(inRateYoda, outRateYoda);
                    System.out.println("Success!");
                    break;
                case 5:
                    System.exit(0);
                    break;
            }
        }
    }
}
