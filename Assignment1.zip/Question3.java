import java.util.Scanner;


public class Question3 {

	static String A1,A2,A3,B1,B2,B3,C1,C2,C3;
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner kb = new Scanner(System.in);
		String lne = kb.nextLine();
		String line[] = lne.split(" ");
		
		assign(line);
		
		A1=Question3.compute(A1);
		A2=Question3.compute(A2);
		A3=Question3.compute(A3);
		B1=Question3.compute(B1);
		B2=Question3.compute(B2);
		B3=Question3.compute(B3);
		C1=Question3.compute(C1);
		C2=Question3.compute(C2);
		C3=Question3.compute(C3);
		display();
               //System.out.println("SPaaaaasadasd");

	}
	
	
	
	private static void assign(String[] line) {
		// TODO Auto-generated method stub
		Question3.A1=line[0]; 
		Question3.B1=line[1];
		Question3.C1=line[2];
		Question3.A2=line[3];
		Question3.B2=line[4];
		Question3.C2=line[5];
		Question3.A3=line[6];
		Question3.B3=line[7];
		Question3.C3=line[8];
	}

	public static void display()
	{
		System.out.println(Question3.A1+" "+Question3.B1+" "+Question3.C1);
		System.out.println(Question3.A2+" "+Question3.B2+" "+Question3.C2);
		System.out.println(Question3.A3+" "+Question3.B3+" "+Question3.C3);
	}
	
	public static int cellval(String cellref)
	{
		switch(cellref){
		case "A1": return Integer.parseInt(Question3.A1);
		case "A2": return Integer.parseInt(Question3.A2);
		case "A3": return Integer.parseInt(Question3.A3);
		case "B1": return Integer.parseInt(Question3.B1);
		case "B2": return Integer.parseInt(Question3.B2);
		case "B3": return Integer.parseInt(Question3.B3);
		case "C1": return Integer.parseInt(Question3.C1);
		case "C2": return Integer.parseInt(Question3.C2);
		case "C3": return Integer.parseInt(Question3.C3);
			default: return 0;
		}
	}
	
	public static String compute(String cell)
	{
		String cellref;
		char op=' ';
		int temp=0; //operator character
			
		if(cell.charAt(0)=='=') //checks if cell is function
			{
				cell=cell.substring(1);
				
				while(cell.length()>2)
				{
				cellref=cell.substring(0, 2);
				//System.out.println(cell);
            op=cell.charAt(2);
				cell=cell.substring(3);
				
				if(op=='+')
				{
					temp+=cellval(cellref);
				}
				else if(op=='-')
				{	
					temp+=-(cellval(cellref));
				}
				
				}
				
				if(cell.length()==2 && op==' ')
				{
					return cellval(cell)+"";
				}
				else if(cell.length()==2)
				{
					if(op=='+')
					{
						temp+=cellval(cell);
					}
					else if(op=='-')
					{	
						temp+=-(cellval(cell));
					}
				}
				return temp+"";
			}
		return cell;
		
	}
	
	


}
