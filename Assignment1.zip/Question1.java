import java.util.*;
public class Question1
{
   public static void main(String asd[])
   {
      String name, country;
      int money;
      Scanner kb = new Scanner(System.in);
      
      System.out.println("Enter full name:");
      name = kb.nextLine();
      System.out.println("Enter sum of money in USD:");
      money = kb.nextInt();
      //Scanner z = new Scanner(System.in);
      System.out.println("Enter country name:");
      String x=kb.nextLine();
      country = kb.nextLine();
     
      System.out.println("\nDearest "+name.split(" ")[0]);
      System.out.println("It is with a heavy heart that I inform you of the death of my father,");
      System.out.println("General Fayk "+name.substring(name.indexOf(' ')+1)+", your long lost relative from Mapsfostol.");
      System.out.println("My father left the sum of "+money+"USD for us, your distant cousins.");
      System.out.println("Unfortunately, we cannot access the money as it is in a bank in "+country+".");
      System.out.println("I desperately need your assistance to access this money.");
      System.out.println("I will even pay you generously, 15% of the amount - "+(int)(0.15*money)+"USD,");
      System.out.println("for your help.  Please get in touch with me at this email address asap.");
      System.out.println("Yours sincerely");
      System.out.println("Arnrial "+name.substring(name.indexOf(' ')+1));
   
   }
}