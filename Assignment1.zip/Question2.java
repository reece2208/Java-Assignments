//import java.Math.*;
import java.util.*;

public class Question2
{
      static Scanner kb = new Scanner(System.in);
      static int n;
      static int m;

      
   public static void main(String asd[])
   {
      //Question2 q2 = new Question2();
      

      
      inputs();
      
      System.out.println("The palindromic perfect squares are as follows:");
      
      for(int i=Question2.n+1;i<Question2.m;i++)
      {
         if(checkpalindrome(i))
         {
            if(Math.sqrt(i)%1==0)
            {
               System.out.println(i);
            }
         }
      }
   }
   
   public static boolean checkpalindrome(int num)
   {
     String rev=""+num;
     String temp="";
     
     for(int i=rev.length();i>0;i--)
     {
        temp+=rev.charAt(i-1);
     }
     if(rev.equals(temp))
     {
      return true;
     }
     else
     {
      return false;
     }
     
   }
   
   public static void inputs()
   {
   System.out.println("Enter the starting point N:");
   Question2.n=Question2.kb.nextInt();
   System.out.println("Enter the ending point M:");
   Question2.m=Question2.kb.nextInt();
   }
}